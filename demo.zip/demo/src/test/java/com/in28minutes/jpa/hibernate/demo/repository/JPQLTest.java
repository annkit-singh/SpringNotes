package com.in28minutes.jpa.hibernate.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.in28minutes.jpa.hibernate.demo.entity.Course;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class JPQLTest {

	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	EntityManager em;

	@Test
	public void findById_basic() {
		Query createQuery = em.createQuery("Select c from Course c");
		List resultList = createQuery.getResultList();
		logger.info("Select c from Course c  {}", resultList);
	}

	@Test
	public void findById_typed() {
		logger.info("Course Information typed \n");
		TypedQuery<Course> createQuery = em.createQuery("Select c from Course c ", Course.class);
		List resultList = createQuery.getResultList();
		logger.info("Select c from Course c  {}", resultList);
	}

	@Test
	public void findById_where() {
		logger.info("Course Information where \n");
		TypedQuery<Course> query = em.createQuery("Select  c  From Course c where name like '%100 Steps'",
				Course.class);

		List<Course> resultList = query.getResultList();

		logger.info("Select  c  From Course c where name like '%100 Steps'-> {}", resultList);
	}

}
