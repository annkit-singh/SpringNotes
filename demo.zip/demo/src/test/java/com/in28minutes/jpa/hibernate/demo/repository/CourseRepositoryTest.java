package com.in28minutes.jpa.hibernate.demo.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.in28minutes.jpa.hibernate.demo.entity.Course;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class CourseRepositoryTest {

	@Autowired
	CourseRepository courseRepo;

	@Test
	public void findById_basic() {
		Course course = courseRepo.findById(100L);
		assertEquals("JPA course", course.getName());
	}

	@Test
	public void deleteById_basic() {
		courseRepo.deleteById(100L);
		Course course = courseRepo.findById(100L);
		assertNull(course);
	}

	@Test
	@DirtiesContext
	public void saveOrUpdateTest() {
		// check it
		Course course = courseRepo.findById(100L);
		// get a course
		course.setName("JPA course-Updated");
		Course cUpdate = courseRepo.saveOrUpdate(course);
		// update it
		assertEquals("JPA course-Updated", cUpdate.getName());
	}

}
