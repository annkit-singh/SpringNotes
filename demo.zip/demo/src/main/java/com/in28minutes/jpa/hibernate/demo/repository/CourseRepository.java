package com.in28minutes.jpa.hibernate.demo.repository;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.in28minutes.jpa.hibernate.demo.entity.Course;

@Repository
public class CourseRepository {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	EntityManager em;

	public Course findById(Long id) {
		return em.find(Course.class, id);
	}

	public void deleteById(Long id) {
		Course course = findById(id);
		em.remove(course);
	}

	public Course saveOrUpdate(Course course) {
		// to add
		if (course == null) {
			em.persist(course);
		}
		// to update
		else {
			em.merge(course);
		}
		return course;
	}

	public void playWithEntityManager() {
		// TODO Auto-generated method stub
		Course course1 = new Course("Luna");
		em.persist(course1);

		Course course2 = new Course("TRX");
		em.persist(course2);

		em.flush();
		// em.clear();
		course1.setName("Luna - Updated");
		em.refresh(course1);
		em.flush();
	}

}