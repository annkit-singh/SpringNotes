package com.in28minutes.mockito.mockitodemo;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SomeBusinessMockAnnotationsTest {

	@Mock
	DataService dataServiceMock;

	@InjectMocks
	SomeBusinessImpl businessImpl;

	@Test
	public void testFindTheGreatestFromAllData() {
		when(dataServiceMock.retrieveAllData()).thenReturn(new int[] { 12, 24, 36 });
		// SomeBusinessImpl someBusinessImpl = new SomeBusinessImpl(dataServiceMock);
		assertEquals(36, businessImpl.findTheGreatestFromAllData());
	}

	@Test
	public void testFindTheLowestFromAllData() {
		when(dataServiceMock.retrieveAllData()).thenReturn(new int[] { 12, 33, 44, 55 });
		assertEquals(12, businessImpl.findTheMinimumFromAllData());
	}

	@Test
	public void checkRangeTest() {
		when(dataServiceMock.retrieveAllData()).thenReturn(new int[] { 000, 1001, 1004 });
		boolean flag = businessImpl.betweenOneTo1000();
		assertEquals(true, flag);

	}

	@Test
	public void extractAlphabetsTest() {
		when(dataServiceMock.retrieveStringData()).thenReturn("Aankit1829Aakash");
		String result = businessImpl.extractAlphabets();
		assertEquals("AankitAakash", result);
	}

	@Test
	public void extractNumsTest() {
		when(dataServiceMock.retrieveStringData()).thenReturn("Aankit1829Aakash");
		Long result = businessImpl.extractNumbers();
		assertEquals(Long.valueOf(1829L), result);

	}

	// @Test
	// public void testFindTheGreatestFromAllData_ForOneValue() {
	// when(dataServiceMock.retrieveAllData()).thenReturn(new int[] { 15 });
	// assertEquals(15, businessImpl.findTheGreatestFromAllData());
	// }

	// @Test
	// public void testFindTheGreatestFromAllData_NoValues() {
	// when(dataServiceMock.retrieveAllData()).thenReturn(new int[] {});
	// assertEquals(Integer.MIN_VALUE, businessImpl.findTheGreatestFromAllData());
	// }
}
