package com.in28minutes.mockito.mockitodemo;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import java.util.List;

public class ListTest {
	@Test
	public void  testListSize() {
		List listMock=mock(List.class);
		when(listMock.size()).thenReturn(8).thenReturn(10);
		assertEquals(8,listMock.size());
		assertEquals(10,listMock.size());
	}
	
	@Test
	public void  testGenericMethod() {
		List listMock=mock(List.class);
		when(listMock.get(Mockito.anyInt())).thenReturn("English");
		assertEquals("English",listMock.get(1));
	}
	
	@Test
	public void testGet_SpecificParameter() {
		List listMock = mock(List.class);
		when(listMock.get(0)).thenReturn("SomeString");
		assertEquals("SomeString", listMock.get(0));
		assertEquals(null, listMock.get(1));
	}

	@Test
	public void testGet_GenericParameter() {
		List listMock = mock(List.class);
		when(listMock.get(Mockito.anyInt())).thenReturn("SomeString");
		assertEquals("SomeString",listMock.get(0));
		assertEquals("SomeString",listMock.get(1));
	}
	
}

