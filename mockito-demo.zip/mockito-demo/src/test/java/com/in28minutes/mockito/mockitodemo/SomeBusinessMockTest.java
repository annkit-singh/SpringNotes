package com.in28minutes.mockito.mockitodemo;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SomeBusinessMockTest {

	@Test
	public void testTheSmallest() {
		DataService dataService = mock(DataService.class);
		when(dataService.retrieveAllData()).thenReturn(new int[] { 22, 33, 44 });
		SomeBusinessImpl someBusinessImpl = new SomeBusinessImpl(dataService);
		int result = someBusinessImpl.findTheMinimumFromAllData();
		assertEquals(22, result);
	}

	@Test
	public void testTheAlphabets() {
		DataService mock = mock(DataService.class);
		when(mock.retrieveStringData()).thenReturn("Delhi6");
		SomeBusinessImpl businessImpl = new SomeBusinessImpl(mock);
		String alphabets = businessImpl.extractAlphabets();
		assertEquals("Delhi", alphabets);
	}
	/*
	 * @Mock DataService dataService;
	 * 
	 * @InjectMocks SomeBusinessImpl someBusinessImpl;
	 * 
	 * 
	 * @Test public void testTheSmallestFromTheData() {
	 * when(dataService.retrieveAllData()).thenReturn(new int[] {2,5,8,3}); int
	 * small=someBusinessImpl.findTheMinimumFromAllData(); assertEquals(2,small); }
	 * 
	 * @Test public void testFindSumOfData() {
	 * when(dataService.retrieveAllData()).thenReturn(new int[] {4,6,7,8}); int
	 * sum=someBusinessImpl.findTheSumOfData(); assertEquals(25,sum); }
	 * 
	 * 
	 * @Test public void testFindTheMaxValue() {
	 * when(dataService.retrieveAllData()).thenReturn(new int[] {}); int
	 * greatest=someBusinessImpl.findTheGreatestFromAllData();
	 * assertEquals(Integer.MIN_VALUE,greatest); }
	 */

}