package com.in28minutes.mockito.mockitodemo;

public class SomeBusinessImpl {
	private DataService dataService;

	public SomeBusinessImpl(DataService dataService) {
		super();
		this.dataService = dataService;
	}

	public SomeBusinessImpl() {
		super();
	}

	int findTheSumOfData() {
		int[] array = dataService.retrieveAllData();
		int sum = 0;
		for (int val : array) {
			sum += val;
		}
		return sum;
	}

	int findTheGreatestFromAllData() {
		int[] data = dataService.retrieveAllData();
		int greatest = Integer.MIN_VALUE;

		for (int value : data) {
			if (value > greatest) {
				greatest = value;
			}
		}
		return greatest;
	}

	int findTheMinimumFromAllData() {
		int[] data = dataService.retrieveAllData();
		int smallest = Integer.MAX_VALUE;

		for (int value : data) {
			if (value < smallest) {
				smallest = value;
			}
		}
		return smallest;
	}

	boolean betweenOneTo1000() {
		int[] data = dataService.retrieveAllData();
		for (int val : data) {
			if (val > 1000 && val < 0) {
				return false;
			}
		}
		return true;

	}

	String extractAlphabets() {
		String data = dataService.retrieveStringData();
		StringBuilder sb = new StringBuilder();
		for (Character ch : data.toCharArray()) {
			if (Character.isAlphabetic(ch)) {
				sb.append(ch);
			}
		}
		return sb.toString();
	}

	Long extractNumbers() {
		String data = dataService.retrieveStringData();
		StringBuilder sb = new StringBuilder();
		for (Character val : data.toCharArray()) {
			if (Character.isDigit(val)) {
				sb.append(val);
			}
		}
		return Long.parseLong((sb.toString()));
	}
}
