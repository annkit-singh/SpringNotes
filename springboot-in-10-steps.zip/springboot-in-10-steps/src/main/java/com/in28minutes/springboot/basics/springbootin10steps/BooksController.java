package com.in28minutes.springboot.basics.springbootin10steps;


import java.util.List;

import java.util.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class BooksController {
	
	@RequestMapping("/books")
	public List<Book> getBooks() {
		return Arrays.asList(
				new Book(1004,"Hero","Jonathan"),
				new Book(1002,"All is well","Penthouse"),
				new Book(1003,"Dream with your eyes open","Shanky Pandey")
						);
				}

}
