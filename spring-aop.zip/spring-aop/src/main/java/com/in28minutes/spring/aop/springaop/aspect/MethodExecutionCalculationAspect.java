package com.in28minutes.spring.aop.springaop.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.in28minutes.spring.aop.springaop.data.Dao1;

//tells the this is AOP file
@Aspect
@Configuration
public class MethodExecutionCalculationAspect {
	
	
@Autowired
Dao1 dao;
	
private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	//@Around("execution(* com.in28minutes.spring.aop.springaop.business.*.*(..))")
	
	@Around("com.in28minutes.spring.aop.springaop.aspect.CommonJoinPointConfig.trackTimeAnnotation()")
	public String around(ProceedingJoinPoint joinPoint) throws Throwable {
		long startTime = System.currentTimeMillis();

		
		joinPoint.proceed();
		

		long timeTaken = System.currentTimeMillis() - startTime;
		logger.info("Time Taken by {} is {}", joinPoint, timeTaken);
		return joinPoint.toString();
	}
}
