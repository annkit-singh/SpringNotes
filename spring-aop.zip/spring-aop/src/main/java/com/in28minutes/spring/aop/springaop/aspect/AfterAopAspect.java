package com.in28minutes.spring.aop.springaop.aspect;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

//tells the this is AOP file
@Aspect
@Configuration
public class AfterAopAspect {

	
private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	//What kind of method calls I would intercept
	//execution(* PACKAGE.*.*(..))
	
	@AfterReturning(value="execution(* com.in28minutes.spring.aop.springaop.business.*.*(..))",returning="result")
	public void afterReturning(JoinPoint joinPoint,Object result){
		logger.info(" Checking for the user access ");
		logger.info(" Allowing for the {} and it is returning the value {} ",joinPoint,result);
	}
	
	@AfterThrowing(value="execution(* com.in28minutes.spring.aop.springaop.business.*.*(..))",throwing="exception")
	public void afterThrowing(JoinPoint joinPoint,Object exception){
		logger.info(" Checking for the user access ");
		logger.info(" Allowing for the {} and it is returning the value {} ",joinPoint,exception);
	}
	
	@After("com.in28minutes.spring.aop.springaop.aspect.CommonJoinPointConfig.businessLayerExecution()")
	public void after(JoinPoint joinPoint){
		logger.info(" Checking for the user access --AFTER METHOD ");
		logger.info(" Allowing for {} ",joinPoint);
	}

}


