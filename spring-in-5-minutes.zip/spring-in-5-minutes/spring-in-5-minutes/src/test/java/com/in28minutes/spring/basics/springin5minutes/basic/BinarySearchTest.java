package com.in28minutes.spring.basics.springin5minutes.basic;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.in28minutes.spring.basics.springin5minutes.SpringIn5MinutesBasicApplication;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes=SpringIn5MinutesBasicApplication.class)
class BinarySearchTest {
@Autowired
BinarySearchImpl binarySearch;

	@Test
	void testBasicScenerio() {
		int result=binarySearch.binarySearch(new int[] {12, 33,9,8},5);
		assertEquals(3, result);
	}
	
}
