package com.in28minutes.spring.basics.springin5minutes.payment;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.in28minutes.spring.basics.springin5minutes.SpringIn5MinutesScopeApplication;


public class PayQuick {
	private static Logger LOGGER=LoggerFactory.getLogger(SpringIn5MinutesScopeApplication.class);
	private SecureGateway secureGateway;
	
	public SecureGateway getSecureGateway() {
		return secureGateway;
	}

	public void setSecureGateway(SecureGateway secureGateway) {
		this.secureGateway = secureGateway;
	}
	
}


