package com.in28minutes.spring.basics.springin5minutes;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.in28minutes.spring.basics.springin5minutes.basic.BinarySearchImpl;
import com.in28minutes.spring.basics.springin5minutes.cdi.SomeCDIBusiness;
import com.in28minutes.spring.basics.springin5minutes.scope.PersonDAO;

@Configuration
@ComponentScan("com.in28minutes.spring.basics.springin5minutes.cdi")
public class SpringIn5MinutesCdiApplication {
	private static Logger LOGGER=LoggerFactory.getLogger(SpringIn5MinutesCdiApplication.class);
	public static void main(String[] args) {
		
		ApplicationContext applicationContext = SpringApplication.run(SpringIn5MinutesCdiApplication.class, args);
//		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(SpringIn5MinutesCdiApplication.class);
		SomeCDIBusiness business=	applicationContext.getBean(SomeCDIBusiness.class);
		LOGGER.info("{} --  dao {}",business,business.getSomeCdiDao());
	}

}
