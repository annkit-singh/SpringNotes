package com.in28minutes.spring.basics.springin5minutes;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.in28minutes.spring.basics.springin5minutes.basic.BinarySearchImpl;
import com.in28minutes.spring.basics.springin5minutes.xml.XmlPersonDAO;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
//@SpringBootApplication
@Configuration
@ComponentScan
public class SpringIn5MinutesXmlContextApplication {

	// What are the beans?
	// What are the dependencies of a bean?
	// Where to search for beans? => No need
	private static Logger LOGGER=LoggerFactory.getLogger(SpringIn5MinutesCdiApplication.class);
	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml")) {
			LOGGER.info("Beans Loaded -> {}", (Object) applicationContext.getBeanDefinitionNames());
			XmlPersonDAO personDAO = applicationContext.getBean(XmlPersonDAO.class);
		
			System.out.println(personDAO.getXmlJdbcConnection());
		}
	}
}