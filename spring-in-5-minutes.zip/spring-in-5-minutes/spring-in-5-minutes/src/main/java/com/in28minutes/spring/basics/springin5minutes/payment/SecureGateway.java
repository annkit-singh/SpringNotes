package com.in28minutes.spring.basics.springin5minutes.payment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.in28minutes.spring.basics.springin5minutes.SpringIn5MinutesScopeApplication;

public class SecureGateway {
	
	private static Logger LOGGER=LoggerFactory.getLogger(SpringIn5MinutesScopeApplication.class);
	public SecureGateway() {
			LOGGER.info("This is the SecureGateway constructor");
		
		
	}

}
