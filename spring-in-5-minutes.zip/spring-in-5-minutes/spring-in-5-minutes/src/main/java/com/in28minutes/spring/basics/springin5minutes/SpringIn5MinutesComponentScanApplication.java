package com.in28minutes.spring.basics.springin5minutes;

import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.slf4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.in28minutes.spring.basics.componentscan.ComponentDAO;
import com.in28minutes.spring.basics.springin5minutes.basic.BinarySearchImpl;
import com.in28minutes.spring.basics.springin5minutes.scope.PersonDAO;

@Configuration
@ComponentScan("com.in28minutes.spring.basics.componentscan")
public class SpringIn5MinutesComponentScanApplication {
	private static Logger LOGGER=LoggerFactory.getLogger(SpringIn5MinutesComponentScanApplication.class);
	public static void main(String[] args) {
		
		//ApplicationContext applicationContext = SpringApplication.run(SpringIn5MinutesComponentScanApplication.class, args);
		
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(SpringIn5MinutesComponentScanApplication.class);
		ComponentDAO personDAO=	applicationContext.getBean(ComponentDAO.class);
		
		LOGGER.info("{}",personDAO);	
	}

}
