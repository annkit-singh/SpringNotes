package com.in28minutes.spring.basics.springin5minutes.basic;

public interface SortAlgorithm {
	
	public int[] sort(int [] numbers) ;

}
