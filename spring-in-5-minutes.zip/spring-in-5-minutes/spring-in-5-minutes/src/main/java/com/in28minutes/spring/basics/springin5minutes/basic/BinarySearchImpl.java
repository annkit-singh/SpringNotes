package com.in28minutes.spring.basics.springin5minutes.basic;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.in28minutes.spring.basics.springin5minutes.SpringIn5MinutesScopeApplication;

@Component
//@Scope("prototype")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
public class BinarySearchImpl {
	private static Logger LOGGER=LoggerFactory.getLogger(SpringIn5MinutesScopeApplication.class);
	@Autowired
	@Qualifier("merge")
	private SortAlgorithm sortAlgorithm;
	
	public int binarySearch(int array[],int element) {
		
		int sortedNumbers[]=	sortAlgorithm.sort(new int[] {12,33,21,55});
		System.out.println(sortAlgorithm);
		return 3;
	}
	
	@PostConstruct
	public void postConstruct() {
		LOGGER.info("This is the post Construct method");
	}
	
	@PreDestroy
	public void preDestroy() {
		LOGGER.info("This is the pre Destroy Method");
	}
}


