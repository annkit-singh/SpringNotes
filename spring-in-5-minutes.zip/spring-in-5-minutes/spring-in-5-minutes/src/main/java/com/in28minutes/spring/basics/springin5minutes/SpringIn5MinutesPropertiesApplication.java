package com.in28minutes.spring.basics.springin5minutes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.in28minutes.spring.basics.springin5minutes.basic.BinarySearchImpl;
import com.in28minutes.spring.basics.springin5minutes.properties.SomeExternalService;

//@SpringBootApplication
@Configuration
@ComponentScan
//@PropertySource(value="file:C:\\Users\\2111683\\app.properties",ignoreResourceNotFound=true)
@PropertySource("classpath:app.properties")
public class SpringIn5MinutesPropertiesApplication {

	// What are the beans?
	// What are the dependencies of a bean?
	// Where to search for beans? => No need

	public static void main(String[] args) {
		try (AnnotationConfigApplicationContext applicationContext = 
				new AnnotationConfigApplicationContext(
						SpringIn5MinutesPropertiesApplication.class)) {

			SomeExternalService someExternalService = 
					applicationContext.getBean(SomeExternalService.class);

			System.out.println("Url which is mentioned in external field "+someExternalService.returnServiceURL());

		}
	}
}