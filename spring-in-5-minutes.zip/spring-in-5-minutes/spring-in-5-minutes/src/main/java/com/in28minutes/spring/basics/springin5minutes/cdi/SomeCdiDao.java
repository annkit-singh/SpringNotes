package com.in28minutes.spring.basics.springin5minutes.cdi;

import javax.inject.Named;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Named
public class SomeCdiDao {

}
