package com.in28minutes.spring.basics.springin5minutes.basic;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Qualifier("merge")
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)

public class MergeSortAlgorithm implements SortAlgorithm{
	public int[] sort(int [] numbers) {
		System.out.println("This is the merge algorithm");
		return numbers;
	}

}
