package com.in28minutes.spring.basics.springin5minutes;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.in28minutes.spring.basics.springin5minutes.basic.BinarySearchImpl;
import com.in28minutes.spring.basics.springin5minutes.scope.PersonDAO;

@SpringBootApplication
public class SpringIn5MinutesScopeApplication {
	private static Logger LOGGER=LoggerFactory.getLogger(SpringIn5MinutesScopeApplication.class);
	public static void main(String[] args) {
		//  BinarySearchImpl binarySearch=new BinarySearchImpl(new MergeSortAlgorithm());
		//	int result=binarySearch.binarySearch(new int [] {12,33,44}, 12);
		//	System.out.println(result);
		//	ConfigurableApplicationContext applicationContext = SpringApplication.run(SpringIn5MinutesApplication.class, args);
		ApplicationContext applicationContext = SpringApplication.run(SpringIn5MinutesScopeApplication.class, args);
		
		PersonDAO personDAO=	applicationContext.getBean(PersonDAO.class);
		
		PersonDAO personDAO2= applicationContext.getBean(PersonDAO.class);
		LOGGER.info("{}",personDAO);
		LOGGER.info("{}", personDAO.getJdbcConnection());
		LOGGER.info("{}", personDAO.getJdbcConnection());
		
		LOGGER.info("{}",personDAO2);
		LOGGER.info("{}", personDAO2.getJdbcConnection());
		
//	    BinarySearchImpl binarySearch=	applicationContext.getBean(BinarySearchImpl.class);
//	    BinarySearchImpl binarySearch1=	applicationContext.getBean(BinarySearchImpl.class);
//	    System.out.println(binarySearch);
//	    System.out.println(binarySearch1);
//	    int result= binarySearch.binarySearch(new int[] {33,44,12,71},3);
//	    System.out.println(result);
		
	}

}
