package com.crud.SpringBootCrudExample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.SpringBootCrudExample.entity.Ticket;
import com.crud.SpringBootCrudExample.repository.TicketRepository;

@Service
public class TicketService {
	
	@Autowired
	TicketRepository ticketRepository;
	
	public void saveTickets(Ticket ticket) {
		ticketRepository.saveTickets(ticket);
		
	}
	
	public List<Ticket> fetchTickets() {
	return	ticketRepository.fetchTickets();
	}

	public void  deleteTickets(int id) {
		ticketRepository.deleteTickets(id);		
	}
	
	public void updateTickets(int id, Ticket ticket) {
		ticketRepository.updateTickets(id,ticket);
	}
}
