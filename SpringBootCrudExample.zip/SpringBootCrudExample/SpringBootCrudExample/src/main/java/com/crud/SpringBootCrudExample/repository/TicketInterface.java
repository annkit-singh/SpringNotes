package com.crud.SpringBootCrudExample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crud.SpringBootCrudExample.entity.Ticket;

public interface TicketInterface extends JpaRepository<Ticket, Integer>{
	

	
}
