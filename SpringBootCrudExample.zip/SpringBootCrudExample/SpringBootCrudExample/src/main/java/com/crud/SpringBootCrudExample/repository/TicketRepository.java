package com.crud.SpringBootCrudExample.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.crud.SpringBootCrudExample.entity.Ticket;

@Repository
public class TicketRepository {
	
	@Autowired
	TicketInterface ticketInterface;
	
	public void saveTickets(Ticket ticket) {
	ticketInterface.save(ticket);	
	}
	
	public List<Ticket> fetchTickets() {
//		ticketInterface.findAll();
		return ticketInterface.findAll();
	}
	
	public void deleteTickets(int id) {
		ticketInterface.deleteById(id);		
	}
	
	public void updateTickets(int id, Ticket ticket) {
	Optional<Ticket> ticketData=	ticketInterface.findById(id);
	if(ticketData.isPresent()) {
		Ticket ticketObject=ticketData.get();
		ticketObject.setAmount(ticket.getAmount());	
		ticketObject.setCatagory(ticket.getCatagory());
		ticketInterface.save(ticketObject);
	}
	}
	

}
