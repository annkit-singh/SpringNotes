package com.hibernate.entityManagerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntityManagerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
