package com.dbrelationship.Hibernate.DB.relationship;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateDbRelationshipApplicationTests {

	@Test
	void contextLoads() {
	}

}
