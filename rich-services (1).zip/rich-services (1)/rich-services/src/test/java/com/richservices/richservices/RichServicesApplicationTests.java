package com.richservices.richservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RichServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
