package com.richservices.richservices.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.richservices.richservices.entity.Post;
import com.richservices.richservices.entity.User;
import com.richservices.richservices.exception.InvalidDeletionException;
import com.richservices.richservices.exception.UserNotFoundException;
import com.richservices.richservices.resources.PostRepository;
import com.richservices.richservices.resources.UserDaoService;
import com.richservices.richservices.resources.UserRepository;

@RestController
public class UserJPAController {
	@Autowired 
	UserDaoService service;
	
	@Autowired
	UserRepository  serviceRepo;
	
	@Autowired
	PostRepository  postRepo;
	
	
	@GetMapping("/jpa/users")
	public List<User> getAllUsers(){
		return serviceRepo.findAll();
	}
	
	@GetMapping("/jpa/users/{id}")
	public EntityModel<User> getById(@PathVariable Integer id){
		Optional<User> user=serviceRepo.findById(id);
		if(!user.isPresent()) {
			throw new UserNotFoundException("id "+id);
		}
		
		//HATEOAS FUNCTIONALITY
		EntityModel<User> resource=EntityModel.of(user.get());
		WebMvcLinkBuilder linkTo=linkTo(methodOn(this.getClass()).getAllUsers());
		resource.add(linkTo.withRel("all-users"));
		return resource;
//		return service.findById(id);
	}
	
	
	
	@DeleteMapping("/jpa/users/{id}")
	public void  deleteById(@PathVariable Integer id){
		Optional<User> user=serviceRepo.findById(id);
		if(!user.isPresent()) {
			throw new InvalidDeletionException("id "+id);
		}
		serviceRepo.deleteById(id);
	}
	


	
	@PostMapping("/jpa/users")
	public ResponseEntity<Object> createUser(@Valid @RequestBody User user) {
		User savedUser = serviceRepo.save(user);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(savedUser.getId())
				.toUri();

		return ResponseEntity.created(location).build();

	}
	
	
	
	
	
	

	
	
	

}
