package com.richservices.richservices.exception;

import java.util.Date;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@RestController
public class CentralisedExceptionController  extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(UserNotFoundException.class)
	public final ResponseEntity<Object> handleUserException(Exception ex, WebRequest request)  {
		MyCustomException exceptionResponse = new MyCustomException(new Date(), ex.getMessage(), request.getDescription(false));
		
		return new ResponseEntity<Object>(exceptionResponse,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(InvalidDeletionException.class)
	public final ResponseEntity<Object> invalidDeletionException(Exception ex, WebRequest request)  {
		MyCustomException exceptionResponse = new MyCustomException(new Date(), "The id you want to delete not existed", request.getDescription(false));
		
		return new ResponseEntity<Object>(exceptionResponse,HttpStatus.NOT_ACCEPTABLE);
	}
	
	protected ResponseEntity<Object> handleMethodArgumentNotValid(
			MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
		MyCustomException exceptionResponse = new MyCustomException(new Date(), "Validation failed", request.getDescription(false));
		return new ResponseEntity<Object>(exceptionResponse,HttpStatus.BAD_REQUEST);
	}
	
	
}
