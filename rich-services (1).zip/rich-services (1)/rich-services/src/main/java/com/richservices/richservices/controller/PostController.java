package com.richservices.richservices.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.richservices.richservices.entity.Post;
import com.richservices.richservices.entity.User;
import com.richservices.richservices.exception.UserNotFoundException;
import com.richservices.richservices.resources.PostRepository;
import com.richservices.richservices.resources.UserRepository;

@RestController
public class PostController {
	@Autowired 
	UserRepository serviceRepo;
	
	@Autowired
	PostRepository postRepo;
	
	@GetMapping("/jpa/users/{id}/posts")
	public List<Post> getAllPostsFromUser(@PathVariable Integer id){
		Optional<User> user = serviceRepo.findById(id);
		if(!user.isPresent()) {
			throw new UserNotFoundException("id "+id);
		}
		return user.get().getPosts();
	}
	
	@GetMapping("/jpa/users/{id}/posts/{postId}")
	public EntityModel<Post> getAllPostsFromUser(@PathVariable Integer id,@PathVariable Integer postId){
		Optional<User> user = serviceRepo.findById(id);
		if(!user.isPresent()) {
			throw new UserNotFoundException("id "+id);
		}
		for(Post post:user.get().getPosts()) {
			
			if(post.getId().equals(postId)) {
				EntityModel<Post> resource=EntityModel.of(post);
				WebMvcLinkBuilder linkTo=linkTo(methodOn(this.getClass()).getAllPostsFromUser(id));
				resource.add(linkTo.withRel("all-post-of-user"));
				return resource;
			}
		}
		
		return null;
	}
	
	
	@PostMapping("/jpa/users/{id}/posts")
	public ResponseEntity<Object> createUser(@PathVariable Integer id, @RequestBody Post post) {
		Optional<User> user = serviceRepo.findById(id);
		if(!user.isPresent()) {
			throw new UserNotFoundException("id "+id);
		}
		post.setUser(user.get());
		postRepo.save(post);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(post.getId())
				.toUri();

		return ResponseEntity.created(location).build();

	}

}
