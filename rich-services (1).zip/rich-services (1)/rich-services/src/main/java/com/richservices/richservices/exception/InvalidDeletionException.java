package com.richservices.richservices.exception;

public class InvalidDeletionException extends RuntimeException{
	
	public InvalidDeletionException(String message) {
		super(message);
	}

}
