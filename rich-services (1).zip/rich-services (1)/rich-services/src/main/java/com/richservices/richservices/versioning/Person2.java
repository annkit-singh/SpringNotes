package com.richservices.richservices.versioning;

public class Person2 {
	
	
	Integer id;
	
	String name;

	public Person2(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Person2() {
		super();
	}

	public Integer getId() {
		return id;
	}

	

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	} 
	
	@Override
	public String toString() {
		return String.format("Person2 [id=%s, name=%s]", id, name);
	}

	
}
