package com.richservices.richservices.resources;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.richservices.richservices.entity.User;

@Service
public class UserDaoService {
	
	private  static List<User> mylist=new ArrayList<>();
	private static int idCounter=0;
	static {
		mylist.add(new User(++idCounter, "Johny", new Date()) );
		mylist.add(new User(++idCounter, "Bira", new Date()) );
		mylist.add(new User(++idCounter, "Kunal", new Date()) );
		mylist.add(new User(++idCounter, "Vijay", new Date()) );	
	}
	
	
	public List<User> retrieveAllUser(){
		return mylist;
	}

	

	public User findById(Integer id){
		for(User user:mylist) {
			if(user.getId().equals(id)) {
				return user;
			}
		}
		return null;
	}
	
	public User deleteById(Integer id) {
		Iterator<User> iterator = mylist.iterator();
		while(iterator.hasNext()) {
			User user = iterator.next();
			if(user.getId()==id) {
				iterator.remove();
				return user;
			}
		}
		return null;
	}
	
	public User save(User user) {
		if(user.getId() == null) {
			user.setId(++idCounter);
			mylist.add(user);
			return user;
		}
		else {
			User todelete=findById(user.getId());
			mylist.remove(todelete);
			mylist.add(user);
			return user;
		}
	
	}
	
	
}
