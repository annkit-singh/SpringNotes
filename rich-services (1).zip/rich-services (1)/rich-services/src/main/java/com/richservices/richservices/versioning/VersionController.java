package com.richservices.richservices.versioning;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class VersionController {
	//URL based versioning
	@GetMapping("v1/person")
	public Person getPerson() {
		return new Person("Charlie");
		
	}
	
	@GetMapping("v2/person")
	public Person2 getPerson2() {
		return new Person2(1001,"Charlie");
		
	}
	
//	parameters based versioning
	@GetMapping(value="/person",params="version=1")
	public Person getPersonParams1() {
		return new Person("Bob Charlie");
	}
	

	@GetMapping(value="/person",params="version=2")
	public Person2 getPersonParams2() {
		return new Person2(102,"Bob Charlie");
	}

	//header based
	
	@GetMapping(value="person/headers",headers="X-API-VERSION=1")
	public Person getPersonParamsHeaders() {
		return new Person("My Bob Charlie");
	}
	
	@GetMapping(value="person/headers",headers="X-API-VERSION=2")
	public Person2 getPersonParamsHeaders2() {
		return new Person2(103,"My Bob Charlie");
	}
	
	
	//produces based versionings here we used Accept header
	@GetMapping(value = "/person/produces", produces = "application/vnd.company.app-v1+json")
	public Person producesV1() {
		return new Person("L Bob Charlie");
	}
	
	@GetMapping(value = "/person/produces", produces = "application/vnd.company.app-v2+json")
	public Person2 producesV2() {
		return new Person2(105,"L Bob Charlie");
	}
}
