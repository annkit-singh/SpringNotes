package com.richservices.richservices.exception;

import java.util.Date;

public class MyCustomException {
	private Date timestamp;
	private String message;
	private String description;
	
	public MyCustomException(Date timestamp, String message, String description) {
		super();
		this.timestamp = timestamp;
		this.message = message;
		this.description = description;
	}
	public Date getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
	public String getMessage() {
		return message;
	}
	
	
	
	

}
